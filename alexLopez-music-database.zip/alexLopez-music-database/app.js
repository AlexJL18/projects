const albums = [
    
{
        
    name:"hakuna matata",
    artist:"Gunna",
    image:"hakunaMatata.jpg",
    genre:"Rap",
    rating:"4/5",
},    
{
        
    name:"Everyobody Talks",
    artist:"Neon Trees",
    image:"everybodyTalks.jpg",
    genre:"Pop",
    rating:"5/5",
},     
{
        
    name:"Davy Crochet",
    artist:"The Backseat Lovers",
    image:"davyCrochet.jpg",
    genre:"Indie",
    rating:"5/5",
},
{
        
    name:"Psychics in LA",
    artist:"Peach Pit",
    image:"psychicsinLA.jpg",
    genre:"Indie",
    rating:"5/5",
},
{
        
    name:"Sweet FA",
    artist:"Peach Pit",
    image:"sweetFA.jpg",
    genre:"Indie",
    rating:"4/5",
},
{
        
    name:"Still a Friend",
    artist:"The Backseat Lovers",
    image:"stillAFriend.jpg",
    genre:"Indie",
    rating:"5/5",
},
{
        
    name:"Something Good Can Work",
    artist:"Two Door Cinema Club",
    image:"somethingGoodCanWork.jpg",
    genre:"Indie",
    rating:"4/5",
},
{
        
    name:"Fire Burning",
    artist:"Sean Kingston",
    image:"fireBurning.jpg",
    genre:"Pop",
    rating:"4/5",
},
{
        
    name:"Runaway Baby",
    artist:"Bruno Mars",
    image:"runawayBaby.jpg",
    genre:"Pop",
    rating:"4/5",
},
{
        
    name:"Make Me Wanna",
    artist:"Thomas Rhett",
    image:"makeMeWanna.jpg",
    genre:"Country",
    rating:"4/5",
},
{
        
    name:"Clouded",
    artist:"Brent Faiyaz",
    image:"clouded.jpg",
    genre:"R&B",
    rating:"5/5",
},
{
        
    name:"ROLLING STONE",
    artist:"Brent Faiyaz",
    image:"rollingStone.jpg",
    genre:"R&B",
    rating:"5/5",
},
{
        
    name:"PRICE OF FAME",
    artist:"Brent Faiyaz",
    image:"priceOfFame.jpg",
    genre:"R&B",
    rating:"5/5",
},
{
        
    name:"Keep Me in Mind",
    artist:"Zac Brown Band",
    image:"KeepMeInMind.jpg",
    genre:"Country",
    rating:"5/5",
},
{
        
    name:"Knee Deep",
    artist:"Zac Brown Band",
    image:"KeepMeInMind.jpg",
    genre:"Country",
    rating:"5/5",
},
{
        
    name:"Island Song",
    artist:"Zac Brown Band",
    image:"islandSong.webp",
    genre:"Country",
    rating:"5/5",
},
{
        
    name:"L's",
    artist:"Nemzzz",
    image:"itsUs.jpg",
    genre:"Rap",
    rating:"4/5",
},
{
        
    name:"Cold Sunday",
    artist:"Lil Yachty",
    image:"coldSunday.jpg",
    genre:"R&B",
    rating:"5/5",
},
{
        
    name:"NEW DROP",
    artist:"Don Toliver",
    image:"newDrop.jpg",
    genre:"Rap",
    rating:"4/5",
},
{
        
    name:"IT'S US",
    artist:"Nemzzz",
    image:"itsUs.jpg",
    genre:"Rap",
    rating:"4/5",
},
]

let container = document.querySelector(".musicContainer");

// albums.forEach(function (album) {
//     let template = `
//     <div class="album">
//     <h1>${album.name}</h1>
//     <h2>${album.artist}</h2>
//     <img src="assets/${album.image}"/>
//     <h2>${album.genre}</h2>
//     <h3>${album.rating}</h3> 
//     </div>
//     `;
//     container.innerHTML += template;
// });

function filter(genre){
    container.innerHTML =" ";
    let sorted = albums.filter(
        album => album.genre == genre
    )
    sorted.forEach(function (album) {
        let template = `
        <div class="album">
        <h1>${album.name}</h1>
        <h2>${album.artist}</h2>
        <img src="assets/${album.image}"/>
        <h2>${album.genre}</h2>
        <h3>${album.rating}</h3> 
        </div>
        `;
        container.innerHTML += template;
    });
}

function reset(){
container.innerHTML =" ";
 albums.forEach(function (album) {
    let template = `
    <div class="album">
    <h1>${album.name}</h1>
    <h2>${album.artist}</h2>
    <img src="assets/${album.image}"/>
    <h2>${album.genre}</h2>
    <h3>${album.rating}</h3> 
    </div>
    `;
    container.innerHTML += template;
});
}
reset()
